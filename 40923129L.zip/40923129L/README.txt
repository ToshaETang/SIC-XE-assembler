OS: windows 10
Language: C
Commpile: gcc main.c
run: a.exe
